fn main() {
    println!("💥✅😕");
}